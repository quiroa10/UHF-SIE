// NetModCfgDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "NetModCfgDemo.h"
#include "NetModCfgDemoDlg.h"
#include "NetModCfgDll.h"
#pragma comment(lib,"NetModCfgDll")

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define     MAX_DEVICECNT   100                                     //�Զ��������豸����
UCHAR		pcmac[6] = {0};											//��ǰMAC��ַ
CHAR		pcip[16] = {0};											//��ǰIP
Mod_MacIP   mod_macip[MAX_DEVICECNT]={0};                           //���ڴ洢���������豸��Ϣ�ṹ������
net_comm    comm_cmd={0};
NetDeviceConfigS  net_cfg = {0};
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetModCfgDemoDlg dialog

CNetModCfgDemoDlg::CNetModCfgDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CNetModCfgDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CNetModCfgDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CNetModCfgDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CNetModCfgDemoDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_Control(pDX, IDC_LIST_DEVICE, m_mlist);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CNetModCfgDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CNetModCfgDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEARCH, OnButtonSearch)
	ON_BN_CLICKED(IDC_BUTTON_SET, OnButtonSet)
	ON_BN_CLICKED(IDC_BUTTON_RESET, OnButtonReset)
	ON_BN_CLICKED(IDC_BUTTON_REFLASH, OnButtonReflash)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_DEVICE, OnDblclkModuleList)
	ON_CBN_SELCHANGE(IDC_COMBO_ADAPTER, OnSelchangeComboAdapter)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CNetModCfgDemoDlg message handlers

BOOL CNetModCfgDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	//��ʼ��listctrl
	m_mlist.ModifyStyle(0, LVS_SHOWSELALWAYS | LVS_SINGLESEL | LVS_REPORT);
	m_mlist.SetExtendedStyle(LVS_EX_GRIDLINES | LVS_EX_FULLROWSELECT);

	{
		m_mlist.InsertColumn(0, "�豸��",LVCFMT_CENTER, 140);	
		m_mlist.InsertColumn(1, "�豸IP",LVCFMT_CENTER, 100);
		m_mlist.InsertColumn(2, "�豸MAC",LVCFMT_CENTER,133);
		m_mlist.InsertColumn(3, "�汾",LVCFMT_CENTER,60);
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CNetModCfgDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CNetModCfgDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CNetModCfgDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//���PC ip&mac
void get_local(PIP_ADAPTER_INFO node)
{
	memset(pcip, 0, sizeof(pcip));
	memcpy(pcmac,node->Address,node->AddressLength);
	strcat(pcip,node->IpAddressList.IpAddress.String);
}

//ö������
int CNetModCfgDemoDlg::get_adapter(int index,BOOL init)
{
	PIP_ADAPTER_INFO padapter_info;
	PIP_ADAPTER_INFO padapter = NULL;
	DWORD ret_val = 0,i=0;
	CHAR tem_tr[128] = "";
	ULONG out_buf_len;
	
	padapter_info = (IP_ADAPTER_INFO *) malloc( sizeof(IP_ADAPTER_INFO) );
	out_buf_len = sizeof(IP_ADAPTER_INFO);
	
	if (GetAdaptersInfo( padapter_info, &out_buf_len) == ERROR_BUFFER_OVERFLOW) 
	{
		free(padapter_info);
		padapter_info = (IP_ADAPTER_INFO *) malloc (out_buf_len); 
	}
	
	if ((ret_val = GetAdaptersInfo( padapter_info, &out_buf_len)) == NO_ERROR) 
	{
		padapter = padapter_info;
		while (padapter) 
		{
		/*	if (padapter->Type != MIB_IF_TYPE_ETHERNET ) {
		padapter = padapter->Next; continue;
		}*/
			i++;
			if (init) 
			{
				sprintf(&tem_tr[0],"%d.%s\0", i,padapter->Description);
				((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTER))->AddString(tem_tr);	
			}
			if ((int)i == index + 1) 
				get_local(padapter);
			padapter = padapter->Next;
		}

		{
			CString	str;
			((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTER))->SetCurSel(index);
			str.Format("IP:%s, MAC: %02X:%02X:%02X:%02X:%02X:%02X",
				pcip, pcmac[0],pcmac[1],pcmac[2],pcmac[3],pcmac[4],pcmac[5]);
			SetDlgItemText(IDC_STATIC_ADAPTERINFO, str);
		}
		return 0;
	} 
	else
	{
		return -1;
	}
}

//�����豸
void CNetModCfgDemoDlg::OnButtonSearch() 
{
	UINT  uDevCnt=0,i=0,index=0;
	char  szBuff[30]="";

	index = m_mlist.GetItemCount();								       //��ȡ�б��е�������
	if(index>0)
	{
		m_mlist.DeleteAllItems();
	}
	memset(mod_macip,0,sizeof(mod_macip));
	uDevCnt=NetMod0_SEARCH(pcip,&mod_macip[0]);
	

	for(i=0;i<uDevCnt;i++)
	{
		index = m_mlist.InsertItem(0,(char*)mod_macip[i].mod_name);    //����һ�У���һ��Ϊģ����
		memset(szBuff,0,sizeof(szBuff));
		sprintf(szBuff,"%d.%d.%d.%d",mod_macip[i].mod_ip[0],mod_macip[i].mod_ip[1],mod_macip[i].mod_ip[2],mod_macip[i].mod_ip[3]);
		m_mlist.SetItemText(index,1,szBuff);
		memset(szBuff,0,sizeof(szBuff));
		sprintf(szBuff,"%02x:%02x:%02x:%02x:%02x:%02x",mod_macip[i].mod_mac[0],mod_macip[i].mod_mac[1],mod_macip[i].mod_mac[2]\
			,mod_macip[i].mod_mac[3],mod_macip[i].mod_mac[4],mod_macip[i].mod_mac[5]);
		m_mlist.SetItemText(index,2,szBuff);
		memset(szBuff,0,sizeof(szBuff));
		sprintf(szBuff,"%d",mod_macip[i].mod_ver);
		m_mlist.SetItemText(index,3,szBuff);
	}

	if(uDevCnt>0)
		AfxMessageBox("�������豸!");
	else
		AfxMessageBox("δ�������豸!");
}

//˫����ȡ�豸����
void CNetModCfgDemoDlg::OnDblclkModuleList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int item;
	net_comm save_cmd={0};
	char  szBuff[300]="";
	
	item = ((LPNMITEMACTIVATE)pNMHDR)->iItem;                             //��ȡ���������ֵ
	
	NetMod0_GETCFG((char*)pcip,(char*)mod_macip[item].mod_mac,&save_cmd);  //��ȡ����
	memcpy(&comm_cmd.data[0],&save_cmd.data[0],save_cmd.len);             //�����ȡ���豸����ֵ�����ýṹ��

    comm_cmd.len = save_cmd.len;

	if(save_cmd.data==NULL)
	{
		AfxMessageBox("��ȡָ���豸����ʧ��!");
		return;
	}
    //��ͨ�Žṹ�������ݸ��Ƶ����ýṹ����
    memcpy(&net_cfg.HWCfg.bDevType,&save_cmd.data[0],save_cmd.len);
	Sleep(1);

	//�������ò�����������net_cfg�ṹ�������ɻ�ȡ
	sprintf(szBuff,"DHCP: %s",net_cfg.HWCfg.bDhcpEnable==1?"�ѿ���":"�ѹر�");
	AfxMessageBox(szBuff);

}


//ˢ������
void CNetModCfgDemoDlg::OnButtonReflash() 
{
	((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTER))->ResetContent();
	get_adapter(0, TRUE);	
}

//�л�����
void CNetModCfgDemoDlg::OnSelchangeComboAdapter() 
{
    get_adapter(((CComboBox*)GetDlgItem(IDC_COMBO_ADAPTER))->GetCurSel(),FALSE);
}

//���ò���
void CNetModCfgDemoDlg::OnButtonSet() 
{
	INT item;
	POSITION pos;
	//��ȡѡ�е��к�
	pos = m_mlist.GetFirstSelectedItemPosition();
	item = m_mlist.GetNextSelectedItem(pos);

	//�������ò�����������net_cfg�ṹ���������޸�
	net_cfg.HWCfg.bDhcpEnable =  1 - net_cfg.HWCfg.bDhcpEnable;

	//�����ýṹ�������ݸ��Ƶ�ͨ�Žṹ����
	memcpy(&comm_cmd.data[0],&net_cfg.HWCfg.bDevType,comm_cmd.len);

    if(NetMod0_SETCFG((char*)pcip,(char*)pcmac,(char*)mod_macip[item].mod_mac,&comm_cmd))
		AfxMessageBox("����ָ���豸���óɹ�!");
}

//�ָ���������
void CNetModCfgDemoDlg::OnButtonReset() 
{
	INT item;
	POSITION pos;
	//��ȡѡ�е��к�
	pos = m_mlist.GetFirstSelectedItemPosition();
	item = m_mlist.GetNextSelectedItem(pos);
	if(NetMod0_RESET((char*)pcip,(char*)mod_macip[item].mod_mac))
		AfxMessageBox("��λָ���豸�ɹ�!");
}
